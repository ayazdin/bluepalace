/*
Theme Name:     <?php echo esc_html($theme_name, "\n"); ?>
Template:       <?php echo esc_html($parent_template, "\n"); ?>

Right to Left text support.
*/
@import url("../<?php echo esc_html($rtl_theme); ?>/rtl.css");
